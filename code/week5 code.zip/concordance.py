
def find_concordance(word_to_find):

    data_file = open('นิราศเมืองแกลง.txt')

    concordance_list = []

    for poem_line in data_file:
        word_list = poem_line.strip().split('|')
        for word_index in range(len(word_list)):
            if word_list[word_index] == word_to_find:
                start_index = max(0, word_index - 3)
                end_index = min(word_index + 3, len(word_list))
                concordance = word_list[start_index:end_index]
                concordance_list.append(concordance)

    output_file_write = open('result.txt', 'w')
    for row in concordance_list:
        string_to_write = ' '.join(row) + '\n'
        output_file_write.write(string_to_write)
    output_file_write.close()

if __name__ == '__main__':
    find_concordance('ว่า')