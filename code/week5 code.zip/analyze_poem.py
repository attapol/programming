def is_word(w):
    return len(w) > 0 and w[0] != '<' and w[0] != 'p'

def count_words():
    count = 0
    # Read file
    input_file = open('นิราศเมืองแกลง.txt')
    word_to_count = {}

    # Loop over each line
    for line in input_file:
        # Loop over each word
        words = line.strip().split('|')
        for word in words:
            if is_word(word):
                if word not in word_to_count:
                    word_to_count[word] = 1
                else:
                    #word_to_count[word] += word_to_count[word]
                    word_to_count[word] = word_to_count[word] + 1
                # update count
                count += 1 # count = count + 1
    #print(word_to_count)
    word_count_pair_list = list(word_to_count.items())
    word_count_pair_list.sort(key=lambda x: x[1], reverse=True)

    output_file = open('word_counts.txt', 'w')
    for pair in word_count_pair_list:
        str_to_print = '{}\t{}\n'.format(pair[0], pair[1])
        output_file.write(str_to_print)
    output_file.close()

    print(word_count_pair_list)
    return count

if __name__  == '__main__':
    count = count_words()
    print (count)